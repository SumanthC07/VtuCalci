# Vtu Sgpa Cgpa Calculator

[![GitHub stars](https://img.shields.io/github/stars/SubramanyaKS/Vtu-sgpa-calculator?style=flat-square)](https://github.com/SubramanyaKS/Vtu-sgpa-calculator/stargazers)
[![GitHub forks](https://img.shields.io/github/forks/SubramanyaKS/Vtu-sgpa-calculator?style=flat-square)](https://github.com/SubramanyaKS/Vtu-sgpa-calculator/network)



This is a mobile application created using Android Studio. This Application will calculate CGPA and SGPA using thee rsult provided by the VTU. I include it for 2015,2017 and 2018 batch students.

### Tools/Technology.
1. ![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=java&logoColor=white)
2. ![Android Studio](https://img.shields.io/badge/Android%20Studio-3DDC84.svg?style=for-the-badge&logo=android-studio&logoColor=white)

### Download.

To download the app click [here](https://github.com/SubramanyaKS/Vtu-sgpa-calculator/blob/main/Vtu_SGPACGPA_Calculator_1.0.apk)

### Pre requesite.

**for download**

* android mobile required

**for forking and run the project**

* Android Studio is required.
* Java jdk is required.


### Contribute.

If there are issues present in project please raise issue and also if you want to contribute feel free to contribute.

If you like this work ⭐ repository.
